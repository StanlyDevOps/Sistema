
Api.Graficas = {
    permisos: []
};