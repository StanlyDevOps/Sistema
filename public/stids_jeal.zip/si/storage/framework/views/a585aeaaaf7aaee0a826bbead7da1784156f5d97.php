<input type="hidden" id="idPadre" value="<?php echo e($idPadre); ?>">
<input type="hidden" id="idHijo" value="<?php echo e($idHijo); ?>">