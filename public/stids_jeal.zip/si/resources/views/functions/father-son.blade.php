<input type="hidden" id="idPadre" value="{{$idPadre}}">
<input type="hidden" id="idHijo" value="{{$idHijo}}">